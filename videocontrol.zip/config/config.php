<?php
/**
 * Created by PhpStorm.
 * User: 10324
 * Date: 2017/12/4
 * Time: 16:23
 */

return array(
    "DB_NAME" => __DIR__ . "/videocontrol.db",
    "qt_port" => 50010,

    "my_ip" => "127.0.0.1",

//    "ip" => "192.168.1.222",
//    "qt_ip" => "192.168.1.222",

    "ip" => "127.0.0.1",
    "qt_ip" => "127.0.0.1",

    "port" => 5001,
    "disk_path" => "/media/disk/",
    "suffix" => ".mp4",
    "my_port" => 5000
);
