<?php
/**
 * Created by PhpStorm.
 * User: 10324
 * Date: 2018/5/20
 * Time: 12:33
 */


echo strval("sfds");